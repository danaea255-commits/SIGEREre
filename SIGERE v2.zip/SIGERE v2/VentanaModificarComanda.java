import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.util.ArrayList;
import javax.swing.*;

public class VentanaModificarComanda extends JPanel implements ActionListener {

    private int idMesa;
    private JPanel panelComandas = new JPanel(new GridLayout(0, 1, 0, 14));

    public VentanaModificarComanda(int idMesa, String nombreMesa) {
        this.idMesa = idMesa;

        setLayout(new BorderLayout());
        setBackground(Estilo.FONDO);

        JPanel titulos = new JPanel(new GridLayout(2, 1, 0, 2));
        titulos.setOpaque(false);
        titulos.add(Estilo.titulo("Modificar comanda: " + nombreMesa));
        titulos.add(Estilo.subtitulo("Quita platillos que el cliente ya no quiere. Cocina verá el cambio al actualizar."));
        add(Estilo.encabezado(titulos, Navegador.botonSalida()), BorderLayout.NORTH);

        panelComandas.setOpaque(false);
        JPanel envoltorio = new JPanel(new BorderLayout());
        envoltorio.setOpaque(false);
        envoltorio.add(panelComandas, BorderLayout.NORTH);
        JScrollPane scroll = new JScrollPane(envoltorio);
        scroll.setBorder(null);
        scroll.getViewport().setBackground(Estilo.FONDO);
        scroll.getVerticalScrollBar().setUnitIncrement(16);
        scroll.setPreferredSize(new Dimension(720, 100));

        JPanel centrado = new JPanel(new GridBagLayout());
        centrado.setOpaque(false);
        centrado.setBorder(BorderFactory.createEmptyBorder(14, 0, 14, 0));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.BOTH;
        gbc.weightx = 1;
        gbc.insets = new Insets(0, 20, 0, 20);
        gbc.weighty = 1;
        centrado.add(scroll, gbc);
        add(centrado, BorderLayout.CENTER);

        cargar();
    }

    private void cargar() {
        panelComandas.removeAll();
        ArrayList<Object[]> comandas = new ArrayList<>();
        try (Connection con = Conexion.conectar()) {
            try (PreparedStatement ps = con.prepareStatement(
                    "SELECT id, cliente, estado_cocina, entregado FROM pedidos "
                  + "WHERE mesa_id = ? AND pagado = 0 AND cancelado = 0 ORDER BY id")) {
                ps.setInt(1, idMesa);
                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) {
                        comandas.add(new Object[]{rs.getInt("id"), rs.getString("cliente"),
                                rs.getString("estado_cocina"), rs.getInt("entregado") == 1});
                    }
                }
            }
            for (Object[] c : comandas) {
                panelComandas.add(crearTarjeta(con, (Integer) c[0], (String) c[1], (String) c[2], (Boolean) c[3]));
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error al cargar la comanda: " + e.getMessage());
        }
        if (comandas.isEmpty()) {
            JLabel vacio = new JLabel("Esta mesa no tiene comandas que se puedan modificar.");
            vacio.setForeground(Estilo.TEXTO_SECUNDARIO);
            panelComandas.add(vacio);
        }
        panelComandas.revalidate();
        panelComandas.repaint();
    }

    private JPanel crearTarjeta(Connection con, int idPedido, String cliente, String estado, boolean entregado)
            throws SQLException {
        JPanel tarjeta = new JPanel(new GridLayout(0, 1, 0, 6));
        tarjeta.setBackground(Estilo.FONDO_TARJETA);
        String situacion = entregado ? "Entregada" : estado;
        tarjeta.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createTitledBorder(
                        BorderFactory.createLineBorder(Estilo.BORDE),
                        "Comanda #" + idPedido + " - " + cliente + " - " + situacion,
                        javax.swing.border.TitledBorder.LEFT, javax.swing.border.TitledBorder.TOP,
                        new Font("Segoe UI", Font.BOLD, 12), Estilo.TEXTO),
                BorderFactory.createEmptyBorder(6, 10, 10, 10)));

        int partidas = 0;
        try (PreparedStatement ps = con.prepareStatement(
                "SELECT d.id, p.nombre, d.cantidad, d.precio_unitario FROM detalle_pedido d "
              + "JOIN platillos p ON p.id = d.platillo_id "
              + "WHERE d.pedido_id = ? AND d.activo = 1 ORDER BY d.id")) {
            ps.setInt(1, idPedido);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    partidas++;
                    int idDetalle = rs.getInt("id");
                    String nombre = rs.getString("nombre");
                    int cantidad = rs.getInt("cantidad");
                    double subtotal = cantidad * rs.getDouble("precio_unitario");

                    JPanel fila = new JPanel(new BorderLayout(10, 0));
                    fila.setOpaque(false);
                    JLabel lbl = new JLabel(cantidad + "x " + nombre + "   ($" + String.format("%.2f", subtotal) + ")");
                    lbl.setFont(new Font("Segoe UI", Font.PLAIN, 14));
                    fila.add(lbl, BorderLayout.CENTER);

                    JPanel botones = new JPanel(new FlowLayout(FlowLayout.RIGHT, 6, 0));
                    botones.setOpaque(false);
                    if (cantidad > 1) {
                        JButton uno = Estilo.botonSecundario("Quitar 1");
                        uno.setActionCommand("U|" + idDetalle + "|" + idPedido);
                        uno.addActionListener(this);
                        botones.add(uno);
                    }
                    JButton todo = Estilo.boton(cantidad > 1 ? "Quitar todo" : "Quitar", Estilo.ROJO);
                    todo.setActionCommand("T|" + idDetalle + "|" + idPedido);
                    todo.addActionListener(this);
                    botones.add(todo);
                    fila.add(botones, BorderLayout.EAST);
                    tarjeta.add(fila);
                }
            }
        }
        if (partidas == 0) {
            JLabel sinPartidas = new JLabel("Esta comanda no tiene platillos editables.");
            sinPartidas.setForeground(Estilo.TEXTO_SECUNDARIO);
            tarjeta.add(sinPartidas);
        }
        return tarjeta;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String comando = e.getActionCommand();
        if (comando == null || comando.indexOf('|') < 0) {
            return;
        }
        String[] partes = comando.split("\\|");
        boolean todo = "T".equals(partes[0]);
        int idDetalle = Integer.parseInt(partes[1]);
        int idPedido = Integer.parseInt(partes[2]);
        quitar(idDetalle, idPedido, todo);
    }

    private String estadoDe(int idPedido) {
        try (Connection con = Conexion.conectar();
             PreparedStatement ps = con.prepareStatement(
                     "SELECT estado_cocina, entregado FROM pedidos WHERE id = ?")) {
            ps.setInt(1, idPedido);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt("entregado") == 1 ? "Entregada" : rs.getString("estado_cocina");
                }
            }
        } catch (Exception ignorada) {
        }
        return "Pendiente";
    }

    private void quitar(int idDetalle, int idPedido, boolean todo) {
        String estado = estadoDe(idPedido);
        String aviso = "";
        if ("En Preparación".equals(estado)) {
            aviso = "\n\nAtención: cocina ya está preparando esta comanda.";
        } else if ("Listo".equals(estado)) {
            aviso = "\n\nAtención: cocina ya marcó esta comanda como lista.";
        } else if ("Entregada".equals(estado)) {
            aviso = "\n\nAtención: esta comanda ya fue entregada a la mesa.";
        }
        int respuesta = JOptionPane.showConfirmDialog(this,
                (todo ? "¿Quitar este platillo por completo de la comanda #" : "¿Quitar una unidad de este platillo en la comanda #")
                        + idPedido + "?" + aviso,
                "Confirmar cambio", JOptionPane.YES_NO_OPTION);
        if (respuesta != JOptionPane.YES_OPTION) {
            return;
        }

        Connection con = null;
        boolean mesaLiberada = false;
        try {
            con = Conexion.conectar();
            con.setAutoCommit(false);

            int cantidad = 0;
            try (PreparedStatement ps = con.prepareStatement(
                    "SELECT cantidad FROM detalle_pedido WHERE id = ? AND pedido_id = ? AND activo = 1")) {
                ps.setInt(1, idDetalle);
                ps.setInt(2, idPedido);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        cantidad = rs.getInt(1);
                    }
                }
            }
            if (cantidad == 0) {
                con.rollback();
                JOptionPane.showMessageDialog(this, "Ese platillo ya había sido modificado. Se actualizará la lista.");
                cargar();
                return;
            }

            String sqlCambio = (todo || cantidad <= 1)
                    ? "UPDATE detalle_pedido SET activo = 0 WHERE id = ?"
                    : "UPDATE detalle_pedido SET cantidad = cantidad - 1 WHERE id = ?";
            try (PreparedStatement ps = con.prepareStatement(sqlCambio)) {
                ps.setInt(1, idDetalle);
                ps.executeUpdate();
            }

            double total = 0;
            int partidas = 0;
            StringBuilder detalle = new StringBuilder();
            try (PreparedStatement ps = con.prepareStatement(
                    "SELECT p.nombre, d.cantidad, d.precio_unitario FROM detalle_pedido d "
                  + "JOIN platillos p ON p.id = d.platillo_id "
                  + "WHERE d.pedido_id = ? AND d.activo = 1 ORDER BY d.id")) {
                ps.setInt(1, idPedido);
                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) {
                        if (partidas > 0) {
                            detalle.append(", ");
                        }
                        detalle.append(rs.getInt("cantidad")).append("x ").append(rs.getString("nombre"));
                        total += rs.getInt("cantidad") * rs.getDouble("precio_unitario");
                        partidas++;
                    }
                }
            }

            if (partidas == 0) {
                try (PreparedStatement ps = con.prepareStatement("UPDATE pedidos SET cancelado = 1 WHERE id = ?")) {
                    ps.setInt(1, idPedido);
                    ps.executeUpdate();
                }
                int restantes = 0;
                try (PreparedStatement ps = con.prepareStatement(
                        "SELECT COUNT(*) FROM pedidos WHERE mesa_id = ? AND pagado = 0 AND cancelado = 0")) {
                    ps.setInt(1, idMesa);
                    try (ResultSet rs = ps.executeQuery()) {
                        rs.next();
                        restantes = rs.getInt(1);
                    }
                }
                if (restantes == 0) {
                    try (PreparedStatement ps = con.prepareStatement(
                            "UPDATE mesas SET estado = 'libre' WHERE id = ? AND estado = 'ocupada'")) {
                        ps.setInt(1, idMesa);
                        ps.executeUpdate();
                        mesaLiberada = true;
                    }
                }
            } else {
                try (PreparedStatement ps = con.prepareStatement(
                        "UPDATE pedidos SET total = ?, detalle = ? WHERE id = ?")) {
                    ps.setDouble(1, total);
                    ps.setString(2, detalle.toString());
                    ps.setInt(3, idPedido);
                    ps.executeUpdate();
                }
            }

            con.commit();

            if (partidas == 0) {
                String mensaje = "La comanda #" + idPedido + " quedó sin platillos y fue cancelada.";
                if (mesaLiberada) {
                    mensaje += "\nLa mesa volvió a estar libre.";
                }
                JOptionPane.showMessageDialog(this, mensaje);
            }
            cargar();

        } catch (Exception ex) {
            if (con != null) {
                try {
                    con.rollback();
                } catch (SQLException ignorada) {
                }
            }
            JOptionPane.showMessageDialog(this, "Error al modificar la comanda: " + ex.getMessage());
        } finally {
            if (con != null) {
                try {
                    con.setAutoCommit(true);
                    con.close();
                } catch (SQLException ignorada) {
                }
            }
        }
    }
}
