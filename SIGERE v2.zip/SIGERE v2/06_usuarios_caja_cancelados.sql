USE saboros;

SET @c := (SELECT COUNT(*) FROM information_schema.COLUMNS
           WHERE TABLE_SCHEMA = 'saboros' AND TABLE_NAME = 'usuario' AND COLUMN_NAME = 'activo');
SET @q := IF(@c = 0, 'ALTER TABLE usuario ADD COLUMN activo TINYINT(1) NOT NULL DEFAULT 1', 'SELECT 1');
PREPARE s FROM @q; EXECUTE s; DEALLOCATE PREPARE s;

SET @c := (SELECT COUNT(*) FROM information_schema.COLUMNS
           WHERE TABLE_SCHEMA = 'saboros' AND TABLE_NAME = 'pedidos' AND COLUMN_NAME = 'cancelado');
SET @q := IF(@c = 0, 'ALTER TABLE pedidos ADD COLUMN cancelado TINYINT(1) NOT NULL DEFAULT 0', 'SELECT 1');
PREPARE s FROM @q; EXECUTE s; DEALLOCATE PREPARE s;

SET @c := (SELECT COUNT(*) FROM information_schema.COLUMNS
           WHERE TABLE_SCHEMA = 'saboros' AND TABLE_NAME = 'detalle_pedido' AND COLUMN_NAME = 'activo');
SET @q := IF(@c = 0, 'ALTER TABLE detalle_pedido ADD COLUMN activo TINYINT(1) NOT NULL DEFAULT 1', 'SELECT 1');
PREPARE s FROM @q; EXECUTE s; DEALLOCATE PREPARE s;

ALTER TABLE usuario
    MODIFY COLUMN rol ENUM('Administrador', 'Mesero', 'Caja') NOT NULL DEFAULT 'Mesero';

INSERT IGNORE INTO usuario (nombre, correo, clave, rol, activo) VALUES
('Cajero de Prueba', 'caja@sigere.com', 'caja123', 'Caja', 1);
