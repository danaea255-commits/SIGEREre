public class Sesion {
    public static String usuario = "";
    public static String correo = "";
    public static String rol = "";

    public static void limpiar() {
        usuario = "";
        correo = "";
        rol = "";
    }
}
