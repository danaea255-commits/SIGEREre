import java.awt.*;
import javax.swing.*;

public class PlanoAdaptable extends JPanel implements Scrollable {
    public PlanoAdaptable() { super(null); }
    @Override public void doLayout() {
        double escala = Math.min(getWidth() / (double) Plano.ANCHO, getHeight() / (double) Plano.ALTO);
        escala = Math.max(0.75, Math.min(1.25, escala));
        int dx = Math.max(0, (getWidth() - (int)(Plano.ANCHO * escala))/2);
        int dy = Math.max(0, (getHeight() - (int)(Plano.ALTO * escala))/2);
        for (Component c : getComponents()) {
            Point p = (Point)((JComponent)c).getClientProperty("posicionPlano");
            if (p != null) c.setBounds(dx+(int)(p.x*escala), dy+(int)(p.y*escala), (int)(Plano.ANCHO_MESA*escala), (int)(Plano.ALTO_MESA*escala));
        }
    }
    public Dimension getPreferredScrollableViewportSize() { return getPreferredSize(); }
    public int getScrollableUnitIncrement(Rectangle r,int o,int d) { return 20; }
    public int getScrollableBlockIncrement(Rectangle r,int o,int d) { return Math.max(20,(o==SwingConstants.HORIZONTAL?r.width:r.height)-20); }
    public boolean getScrollableTracksViewportWidth() { return getParent()!=null && getParent().getWidth()>=Plano.ANCHO*0.75; }
    public boolean getScrollableTracksViewportHeight() { return getParent()!=null && getParent().getHeight()>=Plano.ALTO*0.75; }
    @Override public Dimension getPreferredSize() { return new Dimension((int)(Plano.ANCHO*.75),(int)(Plano.ALTO*.75)); }
}
