import javax.swing.SwingUtilities;
import javax.swing.UIManager;

public class Principal {
    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName());
        } catch (Exception ignorada) {
        }
        SwingUtilities.invokeLater(() -> {
            Navegador.iniciar();
            Navegador.mostrar(new VentanaLogin(), "Acceso");
        });
    }
}
