import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayDeque;
import java.util.Deque;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class Navegador {

    private static class Pantalla {
        final JPanel panel;
        final String titulo;

        Pantalla(JPanel panel, String titulo) {
            this.panel = panel;
            this.titulo = titulo;
        }
    }

    private static JFrame marco;
    private static final Deque<Pantalla> pila = new ArrayDeque<>();
    private static Pantalla actual;

    public static void iniciar() {
        marco = new JFrame("SIGERE");
        java.awt.Rectangle area = java.awt.GraphicsEnvironment.getLocalGraphicsEnvironment().getMaximumWindowBounds();
        marco.setMinimumSize(new Dimension(Math.min(960, area.width), Math.min(640, area.height)));
        marco.setSize(Math.min(1180, area.width), Math.min(760, area.height));
        marco.setLocationRelativeTo(null);
        marco.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        marco.getContentPane().setBackground(Estilo.FONDO);
        marco.getContentPane().setLayout(new BorderLayout());
    }

    public static void mostrar(JPanel panel, String titulo) {
        pila.clear();
        colocar(new Pantalla(panel, titulo));
    }

    public static void ir(JPanel panel, String titulo) {
        if (actual != null) {
            pila.push(actual);
        }
        colocar(new Pantalla(panel, titulo));
    }

    public static void volver() {
        if (!pila.isEmpty()) {
            colocar(pila.pop());
        }
    }

    public static boolean puedeVolver() {
        return !pila.isEmpty();
    }

    public static void cerrarSesion() {
        Sesion.limpiar();
        mostrar(new VentanaLogin(), "Acceso");
    }

    public static JButton botonSalida() {
        return new BotonSalida();
    }

    private static void colocar(Pantalla pantalla) {
        actual = pantalla;
        Container contenido = marco.getContentPane();
        contenido.removeAll();
        contenido.add(pantalla.panel, BorderLayout.CENTER);
        marco.setTitle(pantalla.titulo + " - SIGERE");
        contenido.revalidate();
        contenido.repaint();
        if (!marco.isVisible()) {
            marco.setVisible(true);
        }
    }

    private static class BotonSalida extends JButton implements ActionListener {

        BotonSalida() {
            setFocusPainted(false);
            setOpaque(true);
            setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            setFont(new Font("Segoe UI", Font.BOLD, 13));
            addActionListener(this);
            configurar();
        }

        private void configurar() {
            if (puedeVolver()) {
                setText("\u2190 Regresar");
                setBackground(Estilo.FONDO_TARJETA);
                setForeground(Estilo.TEXTO);
                setBorder(BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(Estilo.BORDE),
                        BorderFactory.createEmptyBorder(8, 16, 8, 16)));
            } else {
                setText("Cerrar Sesión");
                setBackground(Estilo.ROJO);
                setForeground(java.awt.Color.WHITE);
                setBorder(BorderFactory.createEmptyBorder(9, 17, 9, 17));
            }
        }

        @Override
        public void addNotify() {
            super.addNotify();
            configurar();
        }

        @Override
        public void actionPerformed(ActionEvent e) {
            if (puedeVolver()) {
                volver();
            } else {
                cerrarSesion();
            }
        }
    }
}
