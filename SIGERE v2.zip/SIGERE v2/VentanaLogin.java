import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.sql.*;
import javax.imageio.ImageIO;
import javax.swing.*;

public class VentanaLogin extends JPanel implements ActionListener {

    private JTextField txtCorreo = new JTextField();
    private JPasswordField txtClave = new JPasswordField();
    private JLabel lblError = new JLabel(" ");
    private JButton btnEntrar = Estilo.boton("Iniciar Sesión", Estilo.NARANJA);
    private JButton btnCocina = Estilo.boton("Pantalla Cocina", Estilo.OSCURO);

    public VentanaLogin() {
        setLayout(new GridBagLayout());
        setBackground(Estilo.FONDO);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.BOTH;
        gbc.weighty = 1;
        gbc.gridy = 0;

        gbc.gridx = 0;
        gbc.weightx = 0.65;
        add(new PanelImagen(), gbc);

        gbc.gridx = 1;
        gbc.weightx = 0.35;
        add(crearFormulario(), gbc);

        btnEntrar.addActionListener(this);
        btnCocina.addActionListener(this);
        txtCorreo.addActionListener(this);
        txtClave.addActionListener(this);
    }

    private JPanel crearFormulario() {
        JPanel lado = new JPanel(new GridBagLayout());
        lado.setBackground(Estilo.FONDO);

        JPanel tarjeta = new JPanel();
        tarjeta.setLayout(new BoxLayout(tarjeta, BoxLayout.Y_AXIS));
        tarjeta.setOpaque(false);
        tarjeta.setBorder(BorderFactory.createEmptyBorder(16, 12, 16, 12));

        JLabel lblTitulo = new JLabel("SIGERE");
        lblTitulo.setFont(new Font("Segoe UI", Font.BOLD, 38));
        lblTitulo.setForeground(Estilo.NARANJA);
        JLabel lblSub = new JLabel("Sistema de Gestión de Restaurante");
        lblSub.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        lblSub.setForeground(Estilo.TEXTO_SECUNDARIO);
        JLabel lblBienvenida = new JLabel("Inicia sesión para continuar");
        lblBienvenida.setFont(new Font("Segoe UI", Font.BOLD, 16));
        lblBienvenida.setForeground(Estilo.TEXTO);

        tarjeta.add(alinear(lblTitulo));
        tarjeta.add(alinear(lblSub));
        tarjeta.add(Box.createVerticalStrut(30));
        tarjeta.add(alinear(lblBienvenida));
        tarjeta.add(Box.createVerticalStrut(16));
        tarjeta.add(alinear(etiqueta("Correo Electrónico")));
        tarjeta.add(Box.createVerticalStrut(4));
        Estilo.campo(txtCorreo);
        tarjeta.add(ancho(txtCorreo, 42));
        tarjeta.add(Box.createVerticalStrut(12));
        tarjeta.add(alinear(etiqueta("Contraseña")));
        tarjeta.add(Box.createVerticalStrut(4));
        Estilo.campo(txtClave);
        tarjeta.add(ancho(txtClave, 42));
        tarjeta.add(Box.createVerticalStrut(6));
        lblError.setForeground(Estilo.ROJO);
        lblError.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        tarjeta.add(alinear(lblError));
        tarjeta.add(Box.createVerticalStrut(6));
        tarjeta.add(ancho(btnEntrar, 44));
        tarjeta.add(Box.createVerticalStrut(26));

        JSeparator separador = new JSeparator();
        separador.setForeground(Estilo.BORDE);
        tarjeta.add(ancho(separador, 2));
        tarjeta.add(Box.createVerticalStrut(12));
        JLabel lblDirecto = new JLabel("Acceso directo a estaciones");
        lblDirecto.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        lblDirecto.setForeground(Estilo.TEXTO_SECUNDARIO);
        tarjeta.add(alinear(lblDirecto));
        tarjeta.add(Box.createVerticalStrut(8));
        JPanel estaciones = new JPanel(new GridLayout(1, 1));
        estaciones.setOpaque(false);
        estaciones.add(btnCocina);
        tarjeta.add(ancho(estaciones, 42));

        lado.add(tarjeta);
        return lado;
    }

    private JLabel etiqueta(String texto) {
        JLabel l = new JLabel(texto);
        l.setFont(new Font("Segoe UI", Font.BOLD, 12));
        l.setForeground(Estilo.TEXTO);
        return l;
    }

    private JComponent alinear(JComponent c) {
        c.setAlignmentX(Component.LEFT_ALIGNMENT);
        return c;
    }

    private JComponent ancho(JComponent c, int alto) {
        c.setAlignmentX(Component.LEFT_ALIGNMENT);
        c.setPreferredSize(new Dimension(340, alto));
        c.setMaximumSize(new Dimension(Integer.MAX_VALUE, alto));
        return c;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == btnCocina) {
            Navegador.ir(new VentanaCocina(), "Pantalla de Cocina");

        } else if (e.getSource() == txtCorreo) {
            txtClave.requestFocusInWindow();
        } else {
            iniciarSesion();
        }
    }

    private void iniciarSesion() {
        String correo = txtCorreo.getText().trim();
        String clave = new String(txtClave.getPassword()).trim();

        if (correo.isEmpty() || clave.isEmpty()) {
            lblError.setText("Por favor, completa todos los campos.");
            return;
        }

        try (Connection con = Conexion.conectar();
             PreparedStatement ps = con.prepareStatement(
                     "SELECT nombre, correo, clave, rol, activo FROM usuario WHERE correo = ?")) {

            ps.setString(1, correo);
            try (ResultSet rs = ps.executeQuery()) {
                if (!rs.next() || !clave.equals(rs.getString("clave"))) {
                    lblError.setText("Correo o contraseña incorrectos.");
                    return;
                }
                if (rs.getInt("activo") != 1) {
                    lblError.setText("Esta cuenta está desactivada. Consulta al administrador.");
                    return;
                }
                Sesion.usuario = rs.getString("nombre");
                Sesion.correo = rs.getString("correo");
                Sesion.rol = rs.getString("rol");
            }
        } catch (Exception ex) {
            lblError.setText("Error de conexión a la base de datos");
            JOptionPane.showMessageDialog(this, ex.getMessage());
            return;
        }

        if ("Administrador".equals(Sesion.rol)) {
            Navegador.mostrar(new VentanaPanel(), "Panel de Administración");
        } else if ("Caja".equals(Sesion.rol)) {
            Navegador.mostrar(new VentanaCaja(), "Caja y Cobros");
        } else {
            Navegador.mostrar(new VentanaMesas(), "Estación de Mesero");
        }
    }

    private static class PanelImagen extends JPanel {

        private BufferedImage imagen;

        PanelImagen() {
            setPreferredSize(new Dimension(1, 1));
            String[] candidatas = {"img/login.png", "img/login.jpg", "img/login.jpeg"};
            for (String ruta : candidatas) {
                File f = new File(ruta);
                if (f.exists()) {
                    try {
                        imagen = ImageIO.read(f);
                        break;
                    } catch (Exception ignorada) {
                    }
                }
            }
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
            g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BICUBIC);
            g2.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);

            int w = getWidth();
            int h = getHeight();

            if (imagen != null) {
                double escala = Math.max((double) w / imagen.getWidth(), (double) h / imagen.getHeight());
                int iw = (int) Math.ceil(imagen.getWidth() * escala);
                int ih = (int) Math.ceil(imagen.getHeight() * escala);
                g2.drawImage(imagen, (w - iw) / 2, (h - ih) / 2, iw, ih, null);
            } else {
                g2.setPaint(new GradientPaint(0, 0, Estilo.OSCURO, 0, h, Estilo.NARANJA));
                g2.fillRect(0, 0, w, h);
            }

            g2.setPaint(new GradientPaint(0, h * 0.55f, new Color(0, 0, 0, 0), 0, h, new Color(20, 28, 36, 215)));
            g2.fillRect(0, 0, w, h);

            g2.setColor(Color.WHITE);
            g2.setFont(new Font("Segoe UI", Font.BOLD, Math.min(30, Math.max(16, w / 17))));
            g2.drawString("Sabor, orden y control", 20, h - 78);
            g2.setColor(new Color(255, 255, 255, 210));
            g2.setFont(new Font("Segoe UI", Font.PLAIN, Math.min(15, Math.max(10, w / 38))));
            g2.drawString("Comandas, cocina, caja y mesas en un solo lugar.", 20, h - 50);

            g2.dispose();
        }
    }
}
