import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import javax.swing.*;
import javax.swing.border.TitledBorder;

public class VentanaPanel extends JPanel implements ActionListener {

    private JButton btnMenu = Estilo.boton("Gestionar Menú", Estilo.NARANJA);
    private JButton btnMesas = Estilo.boton("Reservaciones y mesas", Estilo.NARANJA);
    private JButton btnPedidos = Estilo.boton("Órdenes y Ventas", Estilo.NARANJA);
    private JButton btnPersonal = Estilo.boton("Control de Personal", Estilo.NARANJA);
    private JButton btnCocina = Estilo.boton("Ver Cocina", Estilo.NARANJA);
    private JButton btnCaja = Estilo.boton("Ver Caja", Estilo.NARANJA);

    private JLabel valVentas = new JLabel("-");
    private JLabel valOrdenes = new JLabel("-");
    private JLabel valMesas = new JLabel("-");
    private JLabel valCocina = new JLabel("-");
    private JLabel resHoy = new JLabel("-");
    private JLabel resMes = new JLabel("-");
    private JLabel resTicket = new JLabel("-");

    public VentanaPanel() {
        setLayout(new BorderLayout(10, 10));
        setBackground(Estilo.FONDO);

        JLabel lblBienvenida = Estilo.subtitulo("Bienvenido, " + Sesion.usuario + "   |   Rol: " + Sesion.rol);
        add(Estilo.encabezado(
                Estilo.titulo("SIGERE - Panel de Administración"),
                Estilo.acciones(lblBienvenida, Navegador.botonSalida())), BorderLayout.NORTH);

        JPanel cuerpo = new JPanel(new BorderLayout(12, 12));
        cuerpo.setOpaque(false);
        cuerpo.setBorder(BorderFactory.createEmptyBorder(8, 15, 15, 15));

        JPanel metricas = new JPanel(new GridLayout(1, 4, 12, 0));
        metricas.setOpaque(false);
        metricas.add(crearTarjeta("VENTAS DE HOY", valVentas));
        metricas.add(crearTarjeta("ÓRDENES PAGADAS HOY", valOrdenes));
        metricas.add(crearTarjeta("MESAS OCUPADAS", valMesas));
        metricas.add(crearTarjeta("EN COCINA", valCocina));
        cuerpo.add(metricas, BorderLayout.NORTH);

        JPanel modulos = new JPanel(new GridLayout(2, 3, 12, 12));
        modulos.setOpaque(false);
        modulos.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(Estilo.BORDE),
                "Módulos del Sistema",
                TitledBorder.LEFT, TitledBorder.TOP,
                new Font("Segoe UI", Font.BOLD, 12), Estilo.TEXTO));
        modulos.add(btnMenu);
        modulos.add(btnMesas);
        modulos.add(btnPersonal);
        modulos.add(btnPedidos);
        modulos.add(btnCocina);
        modulos.add(btnCaja);
        for (JButton b : new JButton[]{btnMenu, btnMesas, btnPersonal, btnPedidos, btnCocina, btnCaja}) {
            b.setFont(new Font("Segoe UI", Font.BOLD, 14));
            b.setText("<html><center>" + b.getText() + "</center></html>");
        }
        
        JPanel contenedorModulos = new JPanel(new BorderLayout());
        contenedorModulos.setOpaque(false);
        contenedorModulos.add(modulos, BorderLayout.CENTER);
        cuerpo.add(contenedorModulos, BorderLayout.CENTER);

        JPanel resumen = new JPanel(new GridLayout(0, 1, 4, 6));
        resumen.setBackground(Estilo.FONDO_TARJETA);
        resumen.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createTitledBorder(
                        BorderFactory.createLineBorder(Estilo.BORDE),
                        "Resumen de ventas",
                        TitledBorder.LEFT, TitledBorder.TOP,
                        new Font("Segoe UI", Font.BOLD, 12), Estilo.TEXTO),
                BorderFactory.createEmptyBorder(4, 10, 4, 10)));
        resumen.setPreferredSize(new Dimension(270, 140));
        resHoy.setForeground(Estilo.TEXTO);
        resHoy.setFont(new Font("Segoe UI", Font.BOLD, 13));
        resMes.setForeground(Estilo.TEXTO);
        resMes.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        resTicket.setForeground(Estilo.TEXTO_SECUNDARIO);
        resTicket.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        resumen.add(resHoy);
        resumen.add(resMes);
        resumen.add(resTicket);
        JPanel contenedorResumen = new JPanel(new BorderLayout());
        contenedorResumen.setOpaque(false);
        contenedorResumen.add(resumen, BorderLayout.CENTER);
        cuerpo.add(contenedorResumen, BorderLayout.EAST);

        add(cuerpo, BorderLayout.CENTER);

        btnMenu.addActionListener(this);
        btnMesas.addActionListener(this);
        btnPedidos.addActionListener(this);
        btnPersonal.addActionListener(this);
        btnCocina.addActionListener(this);
        btnCaja.addActionListener(this);
    }

    private JPanel crearTarjeta(String titulo, JLabel valor) {
        JPanel tarjeta = new JPanel(new GridLayout(2, 1, 0, 4));
        tarjeta.setBackground(Estilo.FONDO_TARJETA);
        tarjeta.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(Estilo.BORDE),
                BorderFactory.createEmptyBorder(14, 16, 14, 16)));
        JLabel lblTitulo = new JLabel(titulo);
        lblTitulo.setForeground(Estilo.TEXTO_SECUNDARIO);
        lblTitulo.setFont(new Font("Segoe UI", Font.BOLD, 11));
        valor.setFont(new Font("Segoe UI", Font.BOLD, 22));
        valor.setForeground(Estilo.TEXTO);
        tarjeta.add(lblTitulo);
        tarjeta.add(valor);
        return tarjeta;
    }

    private double escalar(Statement st, String sql) throws SQLException {
        try (ResultSet rs = st.executeQuery(sql)) {
            return rs.next() ? rs.getDouble(1) : 0;
        }
    }

    private void cargar() {
        try (Connection con = Conexion.conectar();
             Statement st = con.createStatement()) {

            double ventasHoy = escalar(st,
                    "SELECT COALESCE(SUM(total), 0) FROM pedidos WHERE pagado = 1 AND DATE(fecha) = CURDATE()");
            double pagadasHoy = escalar(st,
                    "SELECT COUNT(*) FROM pedidos WHERE pagado = 1 AND DATE(fecha) = CURDATE()");
            double ocupadas = escalar(st,
                    "SELECT COUNT(*) FROM mesas WHERE estado = 'ocupada' AND activa = 1");
            double enCocina = escalar(st,
                    "SELECT COUNT(*) FROM pedidos WHERE entregado = 0 AND cancelado = 0");
            double ventasMes = escalar(st,
                    "SELECT COALESCE(SUM(total), 0) FROM pedidos WHERE pagado = 1 "
                  + "AND MONTH(fecha) = MONTH(CURDATE()) AND YEAR(fecha) = YEAR(CURDATE())");
            double ticket = escalar(st,
                    "SELECT COALESCE(AVG(total), 0) FROM pedidos WHERE pagado = 1 AND DATE(fecha) = CURDATE()");

            valVentas.setText(String.format("$%.2f", ventasHoy));
            valOrdenes.setText(String.valueOf((int) pagadasHoy));
            valMesas.setText(String.valueOf((int) ocupadas));
            valCocina.setText(String.valueOf((int) enCocina));
            resHoy.setText(String.format("Hoy: $%.2f", ventasHoy));
            resMes.setText(String.format("Mes actual: $%.2f", ventasMes));
            resTicket.setText(String.format("Ticket promedio hoy: $%.2f", ticket));
        } catch (Exception e) {
            valVentas.setText("?");
            valOrdenes.setText("?");
            valMesas.setText("?");
            valCocina.setText("?");
            resHoy.setText("Hoy: ?");
            resMes.setText("Mes actual: ?");
            resTicket.setText("Ticket promedio hoy: ?");
        }
    }

    @Override
    public void addNotify() {
        super.addNotify();
        cargar();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == btnMenu) {
            Navegador.ir(new VentanaMenu(), "Gestión de Menú");
        } else if (e.getSource() == btnMesas) {
            Navegador.ir(new VentanaMesas(), "Reservaciones y mesas");
        } else if (e.getSource() == btnPedidos) {
            Navegador.ir(new VentanaPedidos(), "Órdenes y Ventas");
        } else if (e.getSource() == btnPersonal) {
            Navegador.ir(new VentanaUsuarios(), "Control de Personal");
        } else if (e.getSource() == btnCocina) {
            Navegador.ir(new VentanaCocina(), "Cocina (Solo consulta)");
        } else if (e.getSource() == btnCaja) {
            Navegador.ir(new VentanaCaja(), "Caja y Cobros");
        }
    }
}
