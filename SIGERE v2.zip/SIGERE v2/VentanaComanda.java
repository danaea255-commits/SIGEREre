import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.util.ArrayList;
import javax.swing.*;

public class VentanaComanda extends JPanel implements ActionListener {

    private int idMesa;
    private ArrayList<Platillo> platillos = new ArrayList<>();
    private ArrayList<JSpinner> cantidades = new ArrayList<>();
    private JTextField txtCliente = new JTextField();
    private JTextArea txtNotas = new JTextArea(3, 20);
    private JLabel lblTotal = new JLabel("Total: $0.00");
    private JButton btnEnviar = Estilo.boton("Enviar a Cocina y Ocupar Mesa", Estilo.NARANJA);

    public VentanaComanda(int idMesa, String nombreMesa) {
        this.idMesa = idMesa;

        setLayout(new BorderLayout());
        setBackground(Estilo.FONDO);

        add(Estilo.encabezado(
                Estilo.titulo("Atender Mesa: " + nombreMesa),
                Navegador.botonSalida()), BorderLayout.NORTH);

        JPanel cuerpo = new JPanel(new BorderLayout(10, 10));
        cuerpo.setOpaque(false);
        cuerpo.setBorder(BorderFactory.createEmptyBorder(14, 0, 14, 0));
        cuerpo.setPreferredSize(new Dimension(720, 100));

        JPanel norte = new JPanel(new GridLayout(2, 1, 0, 5));
        norte.setOpaque(false);
        norte.add(new JLabel("Nombre del Cliente / Responsable:"));
        Estilo.campo(txtCliente);
        norte.add(txtCliente);
        cuerpo.add(norte, BorderLayout.NORTH);

        JPanel panelMenu = new JPanel(new GridLayout(0, 1, 4, 4));
        panelMenu.setOpaque(false);
        cargarMenu(panelMenu);
        JPanel envoltorio = new JPanel(new BorderLayout());
        envoltorio.setOpaque(false);
        envoltorio.add(panelMenu, BorderLayout.NORTH);
        JScrollPane scroll = new JScrollPane(envoltorio);
        scroll.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(Estilo.BORDE), "Menú con precios (elige la cantidad)"));
        scroll.getViewport().setBackground(Estilo.FONDO_TARJETA);
        scroll.getVerticalScrollBar().setUnitIncrement(16);
        cuerpo.add(scroll, BorderLayout.CENTER);

        lblTotal.setFont(new Font("Segoe UI", Font.BOLD, 18));
        lblTotal.setForeground(Estilo.NARANJA);
        JPanel sur = new JPanel(new BorderLayout(0, 8));
        sur.setOpaque(false);
        sur.add(new JLabel("Notas especiales (sin cebolla, extra salsa, etc.):"), BorderLayout.NORTH);
        txtNotas.setLineWrap(true);
        txtNotas.setWrapStyleWord(true);
        Estilo.campo(txtNotas);
        sur.add(new JScrollPane(txtNotas), BorderLayout.CENTER);
        JPanel pie = new JPanel(new BorderLayout(0, 8));
        pie.setOpaque(false);
        pie.add(lblTotal, BorderLayout.NORTH);
        pie.add(btnEnviar, BorderLayout.SOUTH);
        sur.add(pie, BorderLayout.SOUTH);
        cuerpo.add(sur, BorderLayout.SOUTH);

        JPanel centrado = new JPanel(new GridBagLayout());
        centrado.setOpaque(false);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.BOTH;
        gbc.weightx = 1;
        gbc.insets = new Insets(0, 20, 0, 20);
        gbc.weighty = 1;
        centrado.add(cuerpo, gbc);
        add(centrado, BorderLayout.CENTER);

        btnEnviar.addActionListener(this);
    }

    private void cargarMenu(JPanel panelMenu) {
        try (Connection con = Conexion.conectar();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery("SELECT id, nombre, precio FROM platillos WHERE activo = 1 ORDER BY id")) {

            while (rs.next()) {
                Platillo p = new Platillo(rs.getInt("id"), rs.getString("nombre"), rs.getDouble("precio"));
                JSpinner spinner = new JSpinner(new SpinnerNumberModel(0, 0, 20, 1));
                spinner.addChangeListener(e -> actualizarTotal());
                JPanel fila = new JPanel(new BorderLayout());
                fila.setOpaque(false);
                fila.setBorder(BorderFactory.createEmptyBorder(3, 8, 3, 8));
                fila.add(new JLabel(p.getNombre() + "  ($" + String.format("%.2f", p.getPrecio()) + ")"), BorderLayout.CENTER);
                fila.add(spinner, BorderLayout.EAST);
                panelMenu.add(fila);
                platillos.add(p);
                cantidades.add(spinner);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error al cargar el menú: " + e.getMessage());
        }
    }

    private void actualizarTotal() {
        double total = 0;
        for (int i = 0; i < platillos.size(); i++) {
            int cantidad = Integer.parseInt(cantidades.get(i).getValue().toString());
            total += platillos.get(i).getPrecio() * cantidad;
        }
        lblTotal.setText(String.format("Total: $%.2f", total));
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == btnEnviar) {
            enviar();
        }
    }

    private void enviar() {
        String cliente = txtCliente.getText().trim();
        String notas = txtNotas.getText().trim();
        double total = 0;
        StringBuilder detalle = new StringBuilder();
        int cuantos = 0;

        ArrayList<Object[]> items = new ArrayList<>();

        for (int i = 0; i < platillos.size(); i++) {
            int cantidad = Integer.parseInt(cantidades.get(i).getValue().toString());
            if (cantidad > 0) {
                Platillo p = platillos.get(i);
                total += p.getPrecio() * cantidad;
                if (cuantos > 0) {
                    detalle.append(", ");
                }
                detalle.append(cantidad).append("x ").append(p.getNombre());
                cuantos++;
                items.add(new Object[]{p.getId(), cantidad, p.getPrecio()});
            }
        }

        if (cliente.isEmpty() || cuantos == 0) {
            JOptionPane.showMessageDialog(this, "Escribe el nombre del cliente y elige al menos un platillo.");
            return;
        }

        Connection con = null;
        try {
            con = Conexion.conectar();
            con.setAutoCommit(false);

            int idPedido = 0;
            try (PreparedStatement ps = con.prepareStatement(
                    "INSERT INTO pedidos (mesa_id, cliente, notas, estado_cocina, total, detalle) "
                  + "VALUES (?, ?, ?, 'Pendiente', ?, ?)",
                    Statement.RETURN_GENERATED_KEYS)) {
                ps.setInt(1, idMesa);
                ps.setString(2, cliente);
                ps.setString(3, notas);
                ps.setDouble(4, total);
                ps.setString(5, detalle.toString());
                ps.executeUpdate();
                try (ResultSet keys = ps.getGeneratedKeys()) {
                    if (keys.next()) {
                        idPedido = keys.getInt(1);
                    }
                }
            }

            try (PreparedStatement psDet = con.prepareStatement(
                    "INSERT INTO detalle_pedido (pedido_id, platillo_id, cantidad, precio_unitario) VALUES (?, ?, ?, ?)")) {
                for (Object[] item : items) {
                    psDet.setInt(1, idPedido);
                    psDet.setInt(2, (Integer) item[0]);
                    psDet.setInt(3, (Integer) item[1]);
                    psDet.setDouble(4, (Double) item[2]);
                    psDet.addBatch();
                }
                psDet.executeBatch();
            }

            try (PreparedStatement psMesa = con.prepareStatement("UPDATE mesas SET estado = 'ocupada' WHERE id = ?")) {
                psMesa.setInt(1, idMesa);
                psMesa.executeUpdate();
            }

            con.commit();

            JOptionPane.showMessageDialog(this, "¡Comanda enviada a cocina con éxito y mesa marcada como ocupada!");
            Navegador.volver();

        } catch (Exception ex) {
            if (con != null) {
                try {
                    con.rollback();
                } catch (SQLException ignorada) {
                }
            }
            JOptionPane.showMessageDialog(this, "Error al enviar la comanda: " + ex.getMessage());
        } finally {
            if (con != null) {
                try {
                    con.setAutoCommit(true);
                    con.close();
                } catch (SQLException ignorada) {
                }
            }
        }
    }
}
