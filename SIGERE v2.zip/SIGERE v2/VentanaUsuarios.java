import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;

public class VentanaUsuarios extends JPanel implements ActionListener {

    private static final int COL_ID = 0;
    private static final int COL_CORREO = 2;
    private static final int COL_ROL = 3;
    private static final int COL_ESTADO = 4;

    private DefaultTableModel modelo = new DefaultTableModel(
            new String[]{"ID", "Nombre", "Correo", "Rol", "Estado"}, 0);
    private JTable tabla = new JTable(modelo);
    private JTextField txtNombre = new JTextField();
    private JTextField txtCorreo = new JTextField();
    private JPasswordField txtClave = new JPasswordField();
    private JComboBox<String> cmbRol = new JComboBox<>(new String[]{"Mesero", "Caja", "Administrador"});
    private JButton btnGuardar = Estilo.boton("Guardar Personal", Estilo.NARANJA);
    private JButton btnDesactivar = Estilo.boton("Desactivar Seleccionado", Estilo.ROJO);
    private JButton btnReactivar = Estilo.boton("Reactivar Seleccionado", Estilo.VERDE);

    public VentanaUsuarios() {
        setLayout(new BorderLayout(10, 10));
        setBackground(Estilo.FONDO);

        add(Estilo.encabezado(
                Estilo.titulo("Control de Personal y Credenciales"),
                Navegador.botonSalida()), BorderLayout.NORTH);

        tabla.setDefaultEditor(Object.class, null);
        tabla.setRowHeight(26);
        tabla.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        tabla.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 12));
        tabla.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        tabla.getColumnModel().getColumn(COL_ID).setMaxWidth(60);
        tabla.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable t, Object valor, boolean seleccionada,
                                                           boolean foco, int fila, int columna) {
                Component c = super.getTableCellRendererComponent(t, valor, seleccionada, foco, fila, columna);
                boolean inactivo = "Inactivo".equals(t.getValueAt(fila, COL_ESTADO));
                if (!seleccionada) {
                    c.setForeground(inactivo ? Estilo.GRIS : Estilo.TEXTO);
                }
                return c;
            }
        });
        JScrollPane scroll = new JScrollPane(tabla);
        scroll.setBorder(BorderFactory.createEmptyBorder(0, 15, 0, 15));
        scroll.getViewport().setBackground(Color.WHITE);
        add(scroll, BorderLayout.CENTER);

        JPanel form = new JPanel(new GridLayout(0, 2, 8, 8));
        form.setOpaque(false);
        form.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createTitledBorder("Registrar nuevo personal"),
                BorderFactory.createEmptyBorder(4, 8, 8, 8)));
        form.add(new JLabel("Nombre completo:"));
        form.add(txtNombre);
        form.add(new JLabel("Correo electrónico (usuario):"));
        form.add(txtCorreo);
        form.add(new JLabel("Contraseña temporal:"));
        form.add(txtClave);
        form.add(new JLabel("Rol en el sistema:"));
        form.add(cmbRol);
        form.add(btnDesactivar);
        form.add(btnReactivar);
        form.add(new JLabel(""));
        form.add(btnGuardar);

        JPanel sur = new JPanel(new BorderLayout());
        sur.setOpaque(false);
        sur.setBorder(BorderFactory.createEmptyBorder(0, 15, 15, 15));
        sur.add(form, BorderLayout.CENTER);
        add(sur, BorderLayout.SOUTH);

        btnGuardar.addActionListener(this);
        btnDesactivar.addActionListener(this);
        btnReactivar.addActionListener(this);
        cargar();
    }

    private void cargar() {
        modelo.setRowCount(0);
        try (Connection con = Conexion.conectar();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(
                     "SELECT id, nombre, correo, rol, activo FROM usuario ORDER BY activo DESC, id")) {

            while (rs.next()) {
                modelo.addRow(new Object[]{
                        rs.getInt("id"),
                        rs.getString("nombre"),
                        rs.getString("correo"),
                        rs.getString("rol"),
                        rs.getInt("activo") == 1 ? "Activo" : "Inactivo"
                });
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error al cargar el personal: " + e.getMessage());
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == btnGuardar) {
            guardar();
        } else if (e.getSource() == btnDesactivar) {
            desactivar();
        } else if (e.getSource() == btnReactivar) {
            reactivar();
        }
    }

    private void guardar() {
        String nombre = txtNombre.getText().trim();
        String correo = txtCorreo.getText().trim();
        String clave = new String(txtClave.getPassword()).trim();
        String rol = cmbRol.getSelectedItem().toString();

        if (nombre.isEmpty() || correo.isEmpty() || clave.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Por favor, completa todos los campos.");
            return;
        }

        try (Connection con = Conexion.conectar()) {
            try (PreparedStatement ps = con.prepareStatement(
                    "INSERT INTO usuario (nombre, correo, clave, rol, activo) VALUES (?, ?, ?, ?, 1)")) {
                ps.setString(1, nombre);
                ps.setString(2, correo);
                ps.setString(3, clave);
                ps.setString(4, rol);
                ps.executeUpdate();
                limpiarFormulario();
                cargar();
                JOptionPane.showMessageDialog(this, "¡Personal registrado correctamente!");
            } catch (SQLException e) {
                if (e.getErrorCode() != 1062) {
                    throw e;
                }
                reactivarPorCorreo(con, nombre, correo, clave, rol);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
        }
    }

    private void reactivarPorCorreo(Connection con, String nombre, String correo, String clave, String rol)
            throws SQLException {
        boolean inactivo = false;
        try (PreparedStatement ps = con.prepareStatement("SELECT activo FROM usuario WHERE correo = ?")) {
            ps.setString(1, correo);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    inactivo = rs.getInt("activo") != 1;
                }
            }
        }
        if (!inactivo) {
            JOptionPane.showMessageDialog(this, "Error: El correo ya está registrado.");
            return;
        }
        int respuesta = JOptionPane.showConfirmDialog(this,
                "Ese correo pertenece a un usuario desactivado.\n"
                        + "¿Deseas reactivarlo con los datos que acabas de escribir?",
                "Usuario desactivado", JOptionPane.YES_NO_OPTION);
        if (respuesta != JOptionPane.YES_OPTION) {
            return;
        }
        try (PreparedStatement ps = con.prepareStatement(
                "UPDATE usuario SET nombre = ?, clave = ?, rol = ?, activo = 1 WHERE correo = ?")) {
            ps.setString(1, nombre);
            ps.setString(2, clave);
            ps.setString(3, rol);
            ps.setString(4, correo);
            ps.executeUpdate();
        }
        limpiarFormulario();
        cargar();
        JOptionPane.showMessageDialog(this, "Usuario reactivado correctamente.");
    }

    private void limpiarFormulario() {
        txtNombre.setText("");
        txtCorreo.setText("");
        txtClave.setText("");
        cmbRol.setSelectedIndex(0);
    }

    private int administradoresActivos() throws SQLException {
        try (Connection con = Conexion.conectar();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(
                     "SELECT COUNT(*) FROM usuario WHERE rol = 'Administrador' AND activo = 1")) {
            rs.next();
            return rs.getInt(1);
        }
    }

    private void cambiarEstado(int id, int activo) throws SQLException {
        try (Connection con = Conexion.conectar();
             PreparedStatement ps = con.prepareStatement("UPDATE usuario SET activo = ? WHERE id = ?")) {
            ps.setInt(1, activo);
            ps.setInt(2, id);
            ps.executeUpdate();
        }
        cargar();
    }

    private void desactivar() {
        int fila = tabla.getSelectedRow();
        if (fila == -1) {
            JOptionPane.showMessageDialog(this, "Selecciona un usuario de la tabla.");
            return;
        }

        String correo = modelo.getValueAt(fila, COL_CORREO).toString();
        String rol = modelo.getValueAt(fila, COL_ROL).toString();
        String nombre = modelo.getValueAt(fila, 1).toString();

        if ("Inactivo".equals(modelo.getValueAt(fila, COL_ESTADO))) {
            JOptionPane.showMessageDialog(this, "Este usuario ya está desactivado.");
            return;
        }
        if ("admin@sigere.com".equals(correo)) {
            JOptionPane.showMessageDialog(this, "Este usuario está protegido y no se puede desactivar.");
            return;
        }
        if (correo.equalsIgnoreCase(Sesion.correo)) {
            JOptionPane.showMessageDialog(this, "No puedes desactivar tu propia cuenta mientras tienes la sesión abierta.");
            return;
        }

        try {
            if ("Administrador".equals(rol) && administradoresActivos() <= 1) {
                JOptionPane.showMessageDialog(this, "Debe quedar al menos un administrador activo.");
                return;
            }

            int respuesta = JOptionPane.showConfirmDialog(this,
                    "¿Desactivar a " + nombre + "?\n"
                            + "Ya no podrá iniciar sesión, pero su información se conservará\n"
                            + "y podrás reactivarlo cuando quieras.",
                    "Confirmar", JOptionPane.YES_NO_OPTION);
            if (respuesta != JOptionPane.YES_OPTION) {
                return;
            }
            cambiarEstado(Integer.parseInt(modelo.getValueAt(fila, COL_ID).toString()), 0);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error al desactivar: " + e.getMessage());
        }
    }

    private void reactivar() {
        int fila = tabla.getSelectedRow();
        if (fila == -1) {
            JOptionPane.showMessageDialog(this, "Selecciona un usuario de la tabla.");
            return;
        }
        if ("Activo".equals(modelo.getValueAt(fila, COL_ESTADO))) {
            JOptionPane.showMessageDialog(this, "Este usuario ya está activo.");
            return;
        }
        try {
            cambiarEstado(Integer.parseInt(modelo.getValueAt(fila, COL_ID).toString()), 1);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error al reactivar: " + e.getMessage());
        }
    }
}
